let e = false

export default (function(){

	if(e) return e

	e = {

		npc: [],

		pc: [],

		stations: []

	}

	return e

})()