import User from './User.js'

let user = false

export default (function(){

	if( user ) return user

	return new User()

})()



















