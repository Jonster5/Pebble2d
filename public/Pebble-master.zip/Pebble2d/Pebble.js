class Pebble {
    static info() {
        return `visit www.slidemations.com for info on the Pebble API`;
    }
}